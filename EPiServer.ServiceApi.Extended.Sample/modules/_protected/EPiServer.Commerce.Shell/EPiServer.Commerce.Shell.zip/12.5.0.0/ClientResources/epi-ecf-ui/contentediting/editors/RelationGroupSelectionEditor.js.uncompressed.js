﻿define("epi-ecf-ui/contentediting/editors/RelationGroupSelectionEditor", [
    // dojo
    "dojo/_base/declare",
    // dijit
    "dijit/form/ComboBox",
    // epi
    "epi/dependency"
], function(
    // dojo
    declare,
    // dijit
    ComboBox,
    // epi
    dependency
) {
    return declare([ComboBox], {

        storeKey: "epi.commerce.relationgroupdefinition",

        constructor: function () {
            this.store = this.store || dependency.resolve("epi.storeregistry").get(this.storeKey);
            this.autoComplete = false;
        }
    });
});