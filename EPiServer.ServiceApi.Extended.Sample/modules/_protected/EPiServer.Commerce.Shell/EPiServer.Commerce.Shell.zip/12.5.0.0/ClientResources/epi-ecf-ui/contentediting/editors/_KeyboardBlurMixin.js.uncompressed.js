﻿define("epi-ecf-ui/contentediting/editors/_KeyboardBlurMixin", [
    "dojo/_base/declare",
    "dojo/keys",
    "dijit/focus"
], function (
    declare,
    keys,
    focusUtil
) {
    return declare([], {

        postCreate: function () {
            this.inherited(arguments);
            this.own(this.on("keyDown", this._handleKey));
        },

        _handleKey: function (e) {
            if ((e.keyCode === keys.ENTER) || (e.keyCode === keys.ESCAPE)) {
                e.preventDefault();
                focusUtil.curNode.blur();
            }
        }
    });
});